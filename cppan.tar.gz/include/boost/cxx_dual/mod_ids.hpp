//  (C) Copyright Edward Diener 2015. 
//  Use, modification and distribution are subject to the 
//  Boost Software License, Version 1.0. (See accompanying file 
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#if !defined(CXXD_MOD_IDS_HPP)
#define CXXD_MOD_IDS_HPP

#include <boost/cxx_dual/detail/mod_ids_register.hpp>

#endif // !defined(CXXD_MOD_IDS_HPP)
